<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/mdb.min.css">
    <link rel="stylesheet" href="navbar.css">
    <link rel="shortcut icon" href="img/icon.png" type="image/x-icon">
    <title>Track order</title>
    <style>
        body {
            background-color: #2c2c2c;
        }
        .container {
            margin-top:10%;
        }
        .btn{
            background-color: #2f2f2f;
            border:1px solid whitesmoke;
            color: white;
            margin: 5px;
        }
        #pending:hover{
            background-color: #FFC93C;
            color:white;
        }
        #process:hover{
            background-color: #5D9C59;
            color:white;
        }
        #completed:hover{
            background-color: #E64848;
            color:white;
        }
    </style>
</head>
<body>
    <script src="bootstrap/js/mdb.min.js"></script>
    <div class="container">
        <div class="text-center"><img src="img/logo.png" alt="logo" width="100" height="100"/></div>
        <div class="text-center" style="color:whitesmoke">Track.in</div>
        
        <div class="text-center">
            <button class="btn" id="process" onclick="process()">Process</button>
        </div>
        <div class="text-center">
            <button class="btn" id="completed" onclick="complete()">Completed</button>
        </div>
    </div>
    <?php
        function process(){
            $id = $_GET['order_id']; 
            $conn=new mysqli('localhost','root','','fleet');
            $sql = "UPDATE work_order SET process='process' where order_id=$id";
            if ($conn->query($sql) === TRUE) {
                echo "Record updated successfully";
            } 
        }
        function completed(){
            $id = $_GET['order_id']; 
            $conn=new mysqli('localhost','root','','fleet');
            $sql = "UPDATE work_order SET process='completed' where order_id=$id";
            if ($conn->query($sql) === TRUE) {
                echo "Record updated successfully";
            } 
        }
    ?>
</body>