<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/mdb.min.css">
    <link rel="stylesheet" href="driverEdit.css">
    <title>Edit Menu Info</title>
</head>
<?php
$db=new mysqli('localhost','root','1974','fleet');
if($db->connect_error) {
    die('Connection Failed: ' . $db->connect_error);
}
else{
    $id = $_GET['food_id'];
    $result = $db->query("SELECT * FROM driver_info WHERE food_id=$id ");
    $user = $result->fetch_assoc();
}
?>
<body>
    <script src="bootstrap/js/mdb.min.js"></script>
    <div class=text-center>
        <h1> Edit Menu Infomation </h1>
    </div>
    <div>
    <form action='driverUpdate.php' method='post'>
        <div style="margin-left:34%; margin-top:5%">
            <div class="row">
                <div class="form-group col-md-3">
                <label>Food Id</label>
                <input type="text" id="food_id" name="food_id" class="form-control" value="<?php echo $user['food_id'] ?>"  placeholder="enter the food id" required>
                </div>
                <div class="form-group col-md-3">
                    <label>Truck Id</label>
                    <input type="text" id="truck_id" name="truck_id" class="form-control" value="<?php echo $user['truck_id'] ?>" placeholder="enter the truck id" required>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-3">
                    <label>Menu Name</label>
                    <input type="text" id="menu_name" name="menu_name" class="form-control" value="<?php echo $user['menu_name'] ?>" placeholder="enter the menu name" required>
                    
                </div>
                <div class="form-group col-md-3">
                    <label>Food Name</label>
                    <input type="text" id="food_name" name="food_name" class="form-control" value="<?php echo $user['food_name'] ?>"   placeholder="enter the food name" required>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-3">
                    <label>Price</label>
                    <input type="text" id="price" name="price" class="form-control" value="<?php echo $user['price'] ?>" placeholder="enter the price" required>
                </div>
            </div>
        </div>
        <div class="text-center">
            <button type="submit" style="margin-top:10px;">Save changes</button>
        </div>
        <div class="text-center">
            <button type="button" style="margin-top:10px;" onclick="changeLocation()">Close</button>
        </div>
        </form>
    </div>
    <script>
        function changeLocation(){
            window.location.assign('driver.php')
        }
    </script>
    
</body>