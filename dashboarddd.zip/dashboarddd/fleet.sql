-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2024 at 07:26 AM
-- Server version: 8.0.37
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fleet`
--

-- --------------------------------------------------------

--
-- Table structure for table `driver_info`
--

CREATE TABLE `driver_info` (
  `menu_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `food_id` bigint NOT NULL,
  `truck_id` varchar(25) NOT NULL,
  `food_name` varchar(50) NOT NULL,
  `price` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `driver_info`
--

INSERT INTO `driver_info` (`menu_name`, `food_id`, `truck_id`, `food_name`, `price`) VALUES
('burger', 101, '01', 'veg burger', '110');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(15) NOT NULL,
  `time` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `time`) VALUES
('skameshsurya@gmail.com', '@Srini1974', '2023-02-13'),
('skameshsurya@gmail.com', '@Srini1974', '2023-02-19'),
('skameshsurya@gmail.com', '@Srini1974', '2023-02-19'),
('skameshsurya@gmail.com', '@Srini1974', '2023-02-19'),
('skameshsurya@gmail.com', '@Srini1974', '2023-02-19'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-19'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-20'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-20'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-20'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-27'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-27'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-27'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-27'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-27'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-27'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-27'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-27'),
('skameshsurya@gmail.com', '@Srini1234', '2023-02-27'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-04'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-05'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-05'),
('xxxyyy@gmail.com', '@Srini1974', '2023-03-05'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-07'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-07'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-07'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-08'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-08'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-08'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-08'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-08'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-08'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-08'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-08'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-08'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-09'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-09'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-11'),
('skameshsurya@gmail.com', '@Srini1234', '2023-03-14'),
('skameshsurya@gmail.com', '@Srini1234', '2024-09-22'),
('skameshsurya@gmail.com', '@Srini1234', '2024-09-22'),
('skameshsurya@gmail.com', '@Srini1234', '2024-09-22'),
('skameshsurya@gmail.com', '@Srini1234', '2024-09-22');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`name`, `email`, `password`) VALUES
('karthi', 'kameshsurya@gmail.com', '@Srinivasan1974'),
('karthi', 'skameshsurya@gmail.com', '@Srini1234'),
('surya', 'xxxyyy@gmail.com', '@Srini1974');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_info`
--

CREATE TABLE `vehicle_info` (
  `id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_name` varchar(30) NOT NULL,
  `truck_name` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phno` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vehicle_info`
--

INSERT INTO `vehicle_info` (`id`, `owner_name`, `truck_name`, `location`, `email`, `phno`) VALUES
('01', 'karthi', 'super', 'vellore', 'afdaf@gmail.com', '12345654');

-- --------------------------------------------------------

--
-- Table structure for table `work_order`
--

CREATE TABLE `work_order` (
  `order_id` varchar(50) NOT NULL,
  `food_id` bigint NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `process` varchar(50) NOT NULL,
  `date_of_order` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `work_order`
--

INSERT INTO `work_order` (`order_id`, `food_id`, `quantity`, `total_price`, `process`, `date_of_order`) VALUES
('001', 101, '5', '550', 'In Progress', '2024-09-22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `driver_info`
--
ALTER TABLE `driver_info`
  ADD PRIMARY KEY (`food_id`),
  ADD KEY `truck_id` (`truck_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD KEY `FK_username_login` (`username`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vehicle_info`
--
ALTER TABLE `vehicle_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `work_order`
--
ALTER TABLE `work_order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `food_id` (`food_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `driver_info`
--
ALTER TABLE `driver_info`
  ADD CONSTRAINT `driver_info_ibfk_1` FOREIGN KEY (`truck_id`) REFERENCES `vehicle_info` (`id`);

--
-- Constraints for table `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `FK_username_login` FOREIGN KEY (`username`) REFERENCES `signup` (`email`);

--
-- Constraints for table `work_order`
--
ALTER TABLE `work_order`
  ADD CONSTRAINT `food_id` FOREIGN KEY (`food_id`) REFERENCES `driver_info` (`food_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
