import {Chart, registerables} from '../dist/chart.js';

Chart.register(...registerables);

export * from '../dist/chart.js';
export default Chart;
