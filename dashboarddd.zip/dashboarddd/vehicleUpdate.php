<?php
$id=$_POST['id'];
$owner_name=$_POST['owner_name'];
$truck_name=$_POST['truck_name'];
$location=$_POST['location'];
$email=$_POST['email'];
$phno=$_POST['phno'];

//connection
$conn=new mysqli('localhost','root','1974','fleet');
if($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}
else{
         $sql = "UPDATE vehicle_info SET id='$id', owner_name='$owner_name', truck_name='$truck_name', location='$location', email='$email', phno='$phno' WHERE id='$id'";
        if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
        } else {
        echo "Error updating record: " . $conn->error;
        }
        echo'<script>
                alert("updated");
                window.location.assign("vehicle.php")
            </script>';
}
?>