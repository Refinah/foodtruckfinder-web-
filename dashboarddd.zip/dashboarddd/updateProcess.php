<?php
$conn = mysqli_connect('localhost', 'root', '1974', "fleet");
if (!$conn) {
    die('Connection Failed');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $order_id = $_POST['order_id'];
    $process = $_POST['process'];

    // Update the process in the database
    $stmt = $conn->prepare("UPDATE work_order SET process = ? WHERE order_id = ?");
    $stmt->bind_param("ss", $process, $order_id);

    if ($stmt->execute()) {
        echo '<script>alert("Process updated successfully."); window.location.href = "workOrder.php";</script>';
    } else {
        echo '<script>alert("Error updating process."); window.location.href = "workOrder.php";</script>';
    }

    $stmt->close();
}
$conn->close();
?>
