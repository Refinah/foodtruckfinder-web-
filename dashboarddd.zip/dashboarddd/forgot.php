<?php
$username=$_POST['username'];
//connection
$conn=new mysqli('localhost','root','1974','fleet');
if($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}
else {
    $usrname = "SELECT email FROM signup WHERE email='$username' ";
    $result = $conn->query($usrname);
    $val="empty";
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
          $GLOBALS['val']=$row["email"];
        }
    }
    if($username!=$val)
    {
        echo'<script type="text/javascript">
                alert("incorrect username");
                window.location.assign("forgot.html")
            </script>';
    }
    elseif($username==$val)
    {
        echo"<script type='text/javascript'>
                window.location.assign('resetPwd.html')
            </script>";
        session_start();
        $_SESSION["forgotUser"] = "$username";
    }
}
?>