<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$conn = mysqli_connect('localhost', 'root', '1974', "fleet");
if (!$conn) {
    die('Connection Failed: ' . mysqli_connect_error());
}

// Initialize an empty alert message
$alert_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $food_id = $_POST['food_id'];
    $truck_id = $_POST['truck_id'];
    $menu_name = $_POST['menu_name'];
    $food_name = $_POST['food_name'];
    $price = $_POST['price'];

    // Handling file upload
    $target_dir = "C:/xampp/htdocs/img/"; // Directory where the image will be stored
    $file_name = basename($_FILES["food_image"]["name"]); // Get the original filename
    $target_file = $target_dir . $file_name;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is an actual image or fake image
    $check = getimagesize($_FILES["food_image"]["tmp_name"]);
    if ($check === false) {
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["food_image"]["size"] > 500000) { // Limit file size to 500KB
        $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        $uploadOk = 0;
    }

    // If there's an error, reload the page
    if ($uploadOk == 0) {
        header("Location: driverinfoo.html"); // Redirect to the HTML page
        exit();
    } else {
        // Check if the record already exists in the database
        $check_sql = "SELECT * FROM driver_info WHERE food_image = '$file_name'";
        $result = mysqli_query($conn, $check_sql);

        if (mysqli_num_rows($result) > 0) {
            // The image already exists in the database
            header("Location: driverinfoo.html"); // Redirect to the HTML page
            exit();
        } else {
            // Move the uploaded file
            if (move_uploaded_file($_FILES["food_image"]["tmp_name"], $target_file)) {
                // Insert the data into your database
                $sql = "INSERT INTO driver_info (food_id, truck_id, menu_name, food_name, food_image, price) 
                        VALUES ('$food_id', '$truck_id', '$menu_name', '$food_name', '$file_name', '$price')";
                if (mysqli_query($conn, $sql)) {
                    // Success and redirect
                    header("Location: driverinfo.html"); // Redirect to the HTML page
                    exit();
                } else {
                    header("Location: driverinfo.html"); // Redirect to the HTML page
                    exit();
                }
            } else {
                header("Location: driverinfo.html"); // Redirect to the HTML page
                exit();
            }
        }
    }
}

// Close the database connection
mysqli_close($conn);
?>
