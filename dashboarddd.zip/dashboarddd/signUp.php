<?php
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['pwd'];
$conpwd=$_POST['conpwd'];
//connection
$conn=new mysqli('localhost','root','1974','fleet');
if($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}
else {
    $uppercase = preg_match('@[A-Z]@', $password);
    $lowercase = preg_match('@[a-z]@', $password);
    $number    = preg_match('@[0-9]@', $password);
    $specialChars = preg_match('@[^\w]@', $password);
    if($password!=$conpwd)
    {
        echo'<script>
                alert("Password did not match");
                window.location.assign("signUp.html")
            </script>';
    }
    $sql = "SELECT email FROM signup WHERE email='$email' ";
    $result = $conn->query($sql);
    if(mysqli_num_rows($result) != 0) { 
        echo '<script>
                alert("Account Already Exists");
                window.location.assign("signUp.html")
            </script>';
    }
    else{
        $stmt = $conn->prepare("insert into signup(name,email,password)values(?,?,?)");
        $stmt->bind_param("sss",$name,$email,$password);
        $stmt->execute();
        echo '<script>
                alert("Thanks ! Your account has been successfully created");
                window.location.assign("index.html")
            </script>';
    }
}
?>