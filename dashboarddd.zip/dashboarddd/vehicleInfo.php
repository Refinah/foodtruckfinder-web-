<?php
$id=$_POST['id'];
$owner_name=$_POST['owner_name'];
$truck_name=$_POST['truck_name'];
$location=$_POST['location'];
$email=$_POST['email'];
$phno=$_POST['phno'];

//connection
$conn=new mysqli('localhost','root','1974','fleet');
if($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}
else{
        $stmt = $conn->prepare("insert into vehicle_info(id,owner_name,truck_name,location,email, phno)values(?,?,?,?,?,?)");
        $stmt->bind_param("ssssss",$id,$owner_name,$truck_name,$location,$email,$phno);
        $stmt->execute();
        echo'<script>
                alert("updated");
                window.location.assign("vehicle.php")
            </script>';
}
?>