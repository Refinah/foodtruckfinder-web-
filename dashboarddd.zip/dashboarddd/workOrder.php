<?php
    $conn=mysqli_connect('localhost','root','1974',"fleet");
    if(!$conn) {
        die('Connection Failed');
    }
?>
<?php
    $result = mysqli_query($conn, "
    SELECT wo.order_id, wo.food_id, wo.total_price, wo.quantity, wo.process, fi.food_name 
    FROM work_order wo 
    JOIN driver_info fi ON wo.food_id = fi.food_id
    ORDER BY wo.date_of_order DESC
    ");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" >
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/mdb.min.css">
    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="workOrder.css">
    <title>Food Order</title>
</head>
<body>
    <script src="bootstrap/js/mdb.min.js"></script>
    <header>
        <nav class="navbar fixed-top p-1em">
            <div class="container-fluid">
                    <div class="nav-band">
                        <span class="nav-line1"><img src="img/logo.png" alt="logo" width="75" height="50" style="position: relative; left:0em; top: -1m" /></span>
                        <span class="nav-line2" style="position: relative; left: -0.8em;">Track.in</span>
                    </div>
                    <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="dashboard.php" target="_self">Dashboard</a></li>
                    <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="location.php" target="_self">Location</a></li>
                    <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="driver.php" target="_self">Menu</a></li>
                    <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="vehicle.php" target="_self">Truck</a></li>
                    <li class="nav-item" style="list-style-type: none; color:white;font-weight:bold;"><a class="nav-link" href="workOrder.php" target="_self">Order</a></li>
                    <div class="dropdown">
                        <button id="profile-icon" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle nav-item btn"><i class="far fa-user-circle"></i></button>
                        <div class="dropdown-menu text-center" aria-labelledby="profile-icon">
                            <a class="dropdown-item" href="#"><i class="far fa-user-circle"></i></a>
                            <a class="dropdown-item" href="index.html">
                                <button class="logOut">Log Out</button>
                            </a>
                        </div> 
                    </div>
            </div>
        </nav>
    </header>
    <section class="m-3">
        <div class="card" style="position:relative; top:8em">
            <div class="card-title text-center">
                Food Order
            </div>
            <div class="card-text m-2" style="width:15em">
                <form action="orderSearch.php" method="post">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" id="search" placeholder="Search">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                </form>
            </div>
            <div class="card-body">
                <?php
                if(mysqli_num_rows($result)>0){
                ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Order Id</th>
                            <th scope="col">Food Id</th>
                            <th scope="col">Food Name</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Amount</th>
                            <th scope="col">Process</th>
                        </tr>
                    </thead>
                    <?php
                    $i=0;
                    while($row=mysqli_fetch_array($result)){
                    ?>
                    <tbody>
                        <tr>
                            <td style="font-size:medium; color:black; text-transform:uppercase"><?php echo $row["order_id"]; ?></td>
                            <td style="font-size:medium; color:black; text-transform:uppercase"><?php echo $row["food_id"]; ?></td>
                            <td style="font-size:medium; color:black; text-transform:uppercase"><?php echo $row["food_name"]; ?></td>
                            <td style="font-size:medium; color:black; text-transform:uppercase"><?php echo $row["quantity"]; ?></td>
                            <td style="font-size:medium; color:black; text-transform:uppercase">&#x20b9;<?php echo $row["total_price"]; ?></td>
                            <td style="font-size:medium; color:black; text-transform:uppercase">
                                <form method="POST" action="updateProcess.php">
                                    <input type="hidden" name="order_id" value="<?php echo $row["order_id"]; ?>">
                                    <select name="process" onchange="this.form.submit()">
                                        <option value="Pending" <?php if ($row["process"] == 'Pending') echo 'selected'; ?>>Pending</option>
                                        <option value="In Progress" <?php if ($row["process"] == 'In Progress') echo 'selected'; ?>>In Progress</option>
                                        <option value="Completed" <?php if ($row["process"] == 'Completed') echo 'selected'; ?>>Completed</option>
                                    </select>
                                </form>
                            </td>
                        </tr>
                    </tbody>
                    <?php
                    $i++;
                    }
                    ?>
                </table>
                <?php
                }
                else {
                    echo "no results found";
                }
                ?>
            </div>
        </div>
    </section>
    <footer style="position:absolute; bottom:3em ; left:45%">
        <div>
            <a href="order.html">
                <button type="button" class="btn btn-circle">Assign Order</button>
            </a>
        </div>
    </footer>
</body>
</html>