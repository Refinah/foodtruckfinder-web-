<?php
session_start();
$value=$_SESSION["forgotUser"];
$password=$_POST['pwd'];
$conpwd=$_POST['conpwd'];
//connection
$conn=new mysqli('localhost','root','1974','fleet');
if($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}
else{
    if($password!=$conpwd)
    {
        echo'<script type="text/javascript">
                alert("Password did not match");
                window.location.assign("resetPwd.html")
            </script>';
    }
    else
    {
        $sql = "update signup set password='$password' where email='$value'";
        if(mysqli_query($conn, $sql)){
            echo'<script type="text/javascript">
                alert("Password updated");
                window.location.assign("index.php")
            </script>';   
        } 
    }
}
?>