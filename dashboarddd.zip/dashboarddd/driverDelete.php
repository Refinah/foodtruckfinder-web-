<?php
    $db=new mysqli('localhost','root','1974','fleet');
    if($db->connect_error) {
        die('Connection Failed: ' . $db->connect_error);
    }
    else{
        $id = $_GET['food_id']; 
        $result1 = mysqli_query($db,"select food_id from driver_info where food_id = '$id'"); 
        if(!$result1){
            die(mysqli_error($db));
        }
        
        if (mysqli_num_rows($result1) > 0) {
            while($rowData = mysqli_fetch_array($result1)){
                $num1 = $rowData["food_id"];
            }
        }
        $result2 = mysqli_query($db,"select food_id from work_order where process !='pending' and process!='process' and food_id='$num1' "); 
        if(!$result2){
            die(mysqli_error($db));
        }
        
        if (mysqli_num_rows($result2) > 0) {
            while($rowData = mysqli_fetch_array($result2)){
                $num2 = $rowData["food_id"];
            }
        }
        $del1 = mysqli_query($db,"delete from work_order where food_id = '$id'"); 
        $del2 = mysqli_query($db,"delete from driver_info where food_id = '$id'"); 
        if($del2)
        {
            mysqli_close($db);
            header("location:driver.php");
            exit;
        }
        else
        {
            echo "Error deleting record";
        }
    }
?>