<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" >
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css"
        integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/mdb.min.css">
    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="location.css">
    <title>Location</title>
    <style>
    #map {
        top: 9%;
        height: 90%;
    }
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
    }
    </style>
</head>
<body>
    <script src="bootstrap/js/mdb.min.js"></script>
    <header>
        <nav class="navbar fixed-top p-1em">
            <div class="container-fluid">
                <div class="nav-band ">
                    <span class="nav-line1"><img src="img/logo.png" alt="logo" width="75" height="50"
                            style="position: relative; left:0em; top: -1m" /></span>
                    <span class="nav-line2" style="position: relative; left: -0.8em;">Track.in</span>
                </div>
                <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="dashboard.php"
                        target="_self">Dashboard</a></li>
                <li class="nav-item" style="list-style-type: none; color:white;font-weight:bold;"><a class="nav-link"
                        href="location.php" target="_self">Location</a></li>
                <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="driver.php"
                        target="_self">Menu</a></li>
                <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="vehicle.php"
                        target="_self">Truck</a></li>
                <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="workOrder.php"
                        target="_self">Order</a>
                </li>
                <div class="dropdown">
                    <button id="profile-icon" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle nav-item btn"><i class="far fa-user-circle"></i></button>
                    <div class="dropdown-menu text-center" aria-labelledby="profile-icon">
                        <a class="dropdown-item" href="#"><i class="far fa-user-circle"></i></a>
                        <a class="dropdown-item" href="index.html">
                            <button class="logOut">Log Out</button>
                        </a>
                    </div> 
                </div>
            </div>
        </nav>
    </header>
    <div id="map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d248756.1313127477!2d80.04419746801524!3d13.0474733157774!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5265ea4f7d3361%3A0x6e61a70b6863d433!2sChennai%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1726983362004!5m2!1sen!2sin" style="margin-top:4%" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcG9sf5wj5ajN5yJnerNc6-tHbhi3lDsA"></script>
	<script>
		var locations = [
			{lat: 12.9165, lng: 79.1325, name: 'Vellore'},
			{lat: 13.0827, lng: 80.2707, name: 'Chennai'},
			{lat: 28.7041, lng: 77.1025, name: 'Delhi'}
		];
		function initMap() {
			var map = new google.maps.Map(document.getElementById('map'), {
				zoom: 5,
				center: {lat: 20.7041, lng: 78.9629}
			});
			for (var i = 0; i < locations.length; i++) {
				var location = locations[i];
				var marker = new google.maps.Marker({
					position: location,
					map: map,
					title: location.name
				});

			}
		}
	</script>
	<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcG9sf5wj5ajN5yJnerNc6-tHbhi3lDsA&callback=initMap"></script> -->
</body>
</html>