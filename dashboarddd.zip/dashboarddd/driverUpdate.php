<?php
$food_id=$_POST['food_id'];
$truck_id=$_POST['truck_id'];
$menu_name=$_POST['menu_name'];
$food_name=$_POST['food_name'];
$price=$_POST['price'];

$conn=new mysqli('localhost','root','1974','fleet');
if($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}
else {
        $sql = "UPDATE driver_info SET food_id='$food_id', truck_id='$truck_id', menu_name='$menu_name', food_name='$food_name', price='$price' WHERE food_id=$food_id";
        if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
        } else {
        echo "Error updating record: " . $conn->error;
        }
        echo'<script>
                alert("updated");
                window.location.assign("driver.php")
            </script>';
}
?>