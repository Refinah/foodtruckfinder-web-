<?php
    $search=$_POST["search"];
    $conn=mysqli_connect('localhost','root','1974',"fleet");
    if(!$conn) {
        die('Connection Failed');
    }
    else{
        $query = "SELECT id, truck_name, location  FROM vehicle_info WHERE id='$search'";
        $result = mysqli_query($conn,$query);
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            echo "<script>alert('Truck: ".$row['truck_name'].", location: ".$row['location']."');
            window.location.assign('vehicle.php')
            </script>";
        } else {
            echo "<script>alert('No truck found with the given truck id.');
            window.location.assign('vehicle.php')
            </script>";
        }
    }
?>
