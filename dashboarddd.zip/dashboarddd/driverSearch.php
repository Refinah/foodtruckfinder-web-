<?php
    $search=$_POST["search"];
    $conn=mysqli_connect('localhost','root','1974',"fleet");
    if(!$conn) {
        die('Connection Failed');
    }
    else{
        $query = "SELECT food_id,truck_id,menu_name,food_name, price from driver_info WHERE food_id='$search'";
        $result = mysqli_query($conn,$query);
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            echo "<script>alert('Food Id: ".$row['food_id'].", Truck Id: ".$row['truck_id'].", Menu Name: ".$row['menu_name'].", Food Name: ".$row['food_name'].", Price: ".$row['price']."');
            window.location.assign('driver.php')
            </script>";
        } else {
            echo "<script>alert('No menu found with the given food id.');
            window.location.assign('driver.php')
            </script>";
        }
    }
?>
