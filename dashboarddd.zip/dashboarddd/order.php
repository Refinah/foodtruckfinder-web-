<?php
$order_id = $_POST['order_id'];
$food_id = $_POST['food_id'];
$quantity = $_POST['quantity'];
$process = $_POST['process'];

$conn = new mysqli('localhost', 'root', '1974', 'fleet');
if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
} else {
    // Step 1: Fetch the price from the driver_info table
    $price_query = $conn->prepare("SELECT price FROM driver_info WHERE food_id = ?");
    $price_query->bind_param("s", $food_id);
    $price_query->execute();
    $price_query->bind_result($price);
    $price_query->fetch();
    $price_query->close();

    // Step 2: Calculate total amount
    if ($price) {
        $amount = $price * $quantity;

        // Step 3: Insert into work_order table
        $date = date("Y-m-d");
        $time = strval($date);
        $stmt = $conn->prepare("INSERT INTO work_order (order_id, food_id, quantity, total_price, process, date_of_order) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("ssssss", $order_id, $food_id, $quantity, $amount, $process, $time);
        $stmt->execute();

        echo '<script>
                alert("Ordered successfully.");
                window.location.assign("workOrder.php");
              </script>';
    } else {
        echo '<script>
                alert("Food item not found.");
                window.location.assign("workOrder.php");
              </script>';
    }
}
?>
