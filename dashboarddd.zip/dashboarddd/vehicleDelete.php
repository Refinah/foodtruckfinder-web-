<?php
    $db=new mysqli('localhost','root','1974','fleet');
    if($db->connect_error) {
        die('Connection Failed: ' . $db->connect_error);
    }
    else{
        $id = $_GET['id']; 
        $result = mysqli_query($db,"select truck_id from driver_info where truck_id='$id' "); 
        if(!$result){
            die(mysqli_error($db));
        }
        
        if (mysqli_num_rows($result) > 0) {
            while($rowData = mysqli_fetch_array($result)){
                $num = $rowData["id"];
            }
        }
        $del1 = mysqli_query($db,"delete from driver_info where truck_id = '$id'"); 
        $del2 = mysqli_query($db,"delete from vehicle_info where id = '$id'"); 
        if($del2)
        {
            mysqli_close($db);
            header("location:vehicle.php");
            exit;
        }
        else
        {
            echo "Error deleting record";
        }
    }
    ?>