<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" >
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="bootstrap/css/mdb.min.css">
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="dashboard.css">
    <link rel="shortcut icon" href="img/icon.png" type="image/x-icon">
    <title>Dashboard</title>
</head>
<body>
    <script src="bootstrap/js/mdb.min.js"></script>
    <header>
        <nav class="navbar fixed-top p-0em">
            <div class="container-fluid">
                    <div class="nav-band ">
                        <span class="nav-line1"><img src="img/logo.png" alt="logo" width="75" height="50" style="position: relative; left:0em; top: -1m" /></span>
                        <span class="nav-line2" style="position: relative; left: -0.8em;">Track.in</span>
                    </div>
                    <li class="nav-item" style="list-style-type: none; color:white;font-weight:bold;"><a class="nav-link" href="dashboard.php" target="_self">Dashboard</a></li>
                    <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="location.php" target="_self">Location</a></li>
                    <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="driver.php" target="_self">Menu</a></li>
                    <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="vehicle.php" target="_self">Truck</a></li>
                    <li class="nav-item" style="list-style-type: none;"><a class="nav-link" href="workOrder.php" target="_self">Order</a></li>
                    <div class="dropdown">
                        <button id="profile-icon" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle nav-item btn"><i class="far fa-user-circle"></i></button>
                        <div class="dropdown-menu text-center" aria-labelledby="profile-icon">
                            <a class="dropdown-item" href="#"><i class="far fa-user-circle"></i></a>
                            <a class="dropdown-item" href="index.html">
                                <button class="logOut">Log Out</button>
                            </a>
                        </div> 
                    </div>
            </div>
        </nav>
    </header>
    <section>
        <div class="container">
            <div class="row" style="position:relative;left:130px;">
                <div class="col text-center" style="position:relative;left:50px;">
                    <div class="card w-75 h-75">
                        <div class="card-body p-0">
                            <img src="img/image9.png">
                            <p>Total Truck</p>
                            <p style="color:#16FF00; font-size:20px">
                                <?php
                                $conn=new mysqli('localhost','root','1974','fleet');
                                $sql = "SELECT count(*) as total FROM vehicle_info";
                                $result = $conn->query($sql);
                                if (mysqli_num_rows($result) > 0) {
                                    while($rowData = mysqli_fetch_array($result)){
                                        $total = $rowData["total"].'<br>';
                                    }
                                }
                                echo $total;
                                ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col text-center"style="position:relative;left:50px;">
                    <div class="card w-75 h-75">
                        <div class="card-body p-0">
                            <img src="img/image10.png">
                            <p>In Progress</p>
                            <p style="color:#16FF00; font-size:20px">
                                <?php
                                $conn=new mysqli('localhost','root','1974','fleet');
                                $sql = "SELECT count(*) as total FROM work_order where process='process'";
                                $result = $conn->query($sql);
                                if (mysqli_num_rows($result) > 0) {
                                    while($rowData = mysqli_fetch_array($result)){
                                        $total = $rowData["total"].'<br>';
                                    }
                                }
                                echo $total;
                                ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col text-center">
                    <div class="card w-75 h-75" style="position:relative;left:50px;">
                        <div class="card-body p-0">
                            <img src="img/image8.png">
                            <p>Active</p>
                            <p style="color:#16FF00; font-size:20px">
                                <?php
                                $conn=new mysqli('localhost','root','1974','fleet');
                                $sql = "SELECT count(*) as total FROM work_order where process='pending' or process='completed'";
                                $result = $conn->query($sql);
                                if (mysqli_num_rows($result) > 0) {
                                    while($rowData = mysqli_fetch_array($result)){
                                        $total = $rowData["total"].'<br>';
                                    }
                                }
                                echo $total;
                                ?>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row" style="position:relative;left:80px">

            <div class="col text-center" style="position:relative;left:50px">
                <div id="status" style="width:400px;height:350px;"></div>
                <?php
                // Query to count work orders by their status
                $conn = new mysqli('localhost', 'root', '1974', 'fleet');
                $sql = "SELECT process, COUNT(*) as count FROM work_order GROUP BY process";
                $result = mysqli_query($conn, $sql);
                $data = mysqli_fetch_all($result, MYSQLI_ASSOC);
                $json_data = json_encode($data);
                ?>
                <script>
                    var data = <?php echo $json_data ?>;
                    var xValues = data.map(item => item.process);  // Extract process names
                    var yValues = data.map(item => item.count);    // Extract counts

                    var layout = {title: "Distribution of Work Orders by Status"};
                    var pieData = [{
                        labels: xValues,
                        values: yValues,
                        type: "pie",
                        textinfo: "label+percent", // Display label and percentage
                        insidetextorientation: "radial" // Makes it easier to read
                    }];
                    Plotly.newPlot("status", pieData, layout);
                </script>
            </div>

            <div class="col text-center" style="position:relative;left:50px">
                <div id="cover" style="width:400px;height:350px;"></div>
                <?php
                // Connect to the database
                $conn = new mysqli('localhost', 'root', '1974', 'fleet');

                // Query to count the number of trucks per destination
                $sql = "SELECT location, COUNT(*) as count FROM vehicle_info GROUP BY location";
                $result = mysqli_query($conn, $sql);
                $data = mysqli_fetch_all($result, MYSQLI_ASSOC);
                $json_data = json_encode($data);
                ?>
                <script>
                    var data = <?php echo $json_data ?>;
                    var xValues = [];
                    var yValues = [];

                    // Extracting the destination names and counts
                    for (var i = 0; i < data.length; i++) {
                        xValues.push(data[i].destination);
                        yValues.push(data[i].count);
                    }

                    var layout = {title: "Number of Trucks in Each Location"};
                    var pieData = [{
                        labels: xValues,
                        values: yValues,
                        type: "pie",
                        textinfo: "label+percent", // Display label and percentage
                        insidetextorientation: "radial" // Makes it easier to read
                    }];
                    Plotly.newPlot("cover", pieData, layout);
                </script>
            </div>


            <div class="col text-center" style="position:relative;left:50px">
                <div id="orders" style="width:400px;height:350px;"></div>
                <?php
                $conn=new mysqli('localhost','root','1974','fleet');
                $sql = "SELECT date_of_order, COUNT(*) as count FROM work_order GROUP BY date_of_order";
                $result = mysqli_query($conn, $sql);
                $data = mysqli_fetch_all($result, MYSQLI_ASSOC);
                $json_data = json_encode($data);
                ?>
                <script>
                    var data = <?php echo $json_data ?>;
                    var xValues=[];
                    var yValues=[];
                    for(var i=0; i<data.length; i++)
                    {
                        xValues.push(data[i].date_of_order);
                        yValues.push(data[i].count);
                    }
                    var layout = {title:"weekly orders"};
                    var data = [{labels:xValues, values:yValues, hole: .6, type:"pie"}];
                    Plotly.newPlot("orders", data, layout);
                </script>
            </div>

            </div>
        </div>
    </section>
</body>
</html>