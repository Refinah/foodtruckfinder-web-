<?php
    $search=$_POST["search"];
    $conn=mysqli_connect('localhost','root','1974',"fleet");
    if(!$conn) {
        die('Connection Failed');
    }
    else{
        $query = "SELECT order_id, food_id, total_price, process from work_order WHERE order_id=$search";
        $result = mysqli_query($conn,$query);
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            echo "<script>alert('order id: ".$row['order_id'].", Food id: ".$row['food_id'].", Total price: ".$row['total_price'].", process: ".$row['process']."');
            window.location.assign('workOrder.php')
            </script>";
        } else {
            echo "<script>alert('No order found with the given order id.');
            window.location.assign('workOrder.php')
            </script>";
        }
    }
?>
