<?php
$username=$_POST['username'];
$password=$_POST['password'];
//connection
$conn=new mysqli('localhost','root','1974','fleet');
if($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}
else {
    $usrname = "SELECT email FROM signup WHERE email='$username' ";
    $result1 = $conn->query($usrname);
    $pwd = "SELECT signup.password FROM signup WHERE email='$username' ";
    $result2 = $conn->query($pwd);
    $check1 = "empty";
    $check2 = "empty";
    if ($result1->num_rows > 0) {
        while($row = $result1->fetch_assoc()) {
          $GLOBALS['check1']=$row["email"];
        }
    }
    if ($result2->num_rows > 0) {
        while($row = $result2->fetch_assoc()) {
          $GLOBALS['check2']=$row["password"];
        }
    }
    
    if($check1==$username && $check2!=$password)
    {
        echo'<script type="text/javascript">
                alert("incorrect password");
                window.location.assign("index.html")
            </script>';
    }
    if($check1!=$username)
    {
        echo'<script type="text/javascript">
                alert("invaild user");
                window.location.assign("index.html")
            </script>';
    }
    if($check1==$username && $check2==$password)
    {
        $date = date("Y-m-d");
        $time = strval($date);
        $stmt = $conn->prepare("insert into login(username,password,time)values(?,?,?)");
        $stmt->bind_param("sss",$username,$password,$time);
        $stmt->execute();
        
        echo"<script type='text/javascript'>
                alert('logged in');
                localStorage.setItem('username', '$username');
                window.location.assign('dashboard.php')
            </script>";
    }
}
?>