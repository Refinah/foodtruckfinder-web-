<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>>
</head>
<?php
$db=new mysqli('localhost','root','1974','fleet');
if($db->connect_error) {
    die('Connection Failed: ' . $db->connect_error);
}
else{
    $email = "<script>document.write(localStorage.getItem('username'));</script>";;
    $result = $db->query("SELECT username, password FROM login WHERE username='$email'");
    $user = $result->fetch_assoc();
}
?>
<body>
<form>
        <h1> PROFILE </h1>
        <label>User Name</label>
        <input type="text" name="name" id="name" value="<?php echo $user['username'] ?>" required>
        <label>Password</label>
        <input type="text" name="pwd" id="pwd" value="<?php echo $user['password'] ?>" required>
        <button>Save Changes</button>
    </form>
</body>
</html>