<?php
// Required if your environment does not handle autoloading
require __DIR__ . '/vendor/autoload.php';

$sid = "AC5c92849f2a68012aa61a1e408c241ff0"; // Your Account SID from https://console.twilio.com
$token = "3c7634932c01c01e7220561bb6522d97"; // Your Auth Token from https://console.twilio.com
$client = new Twilio\Rest\Client($sid, $token);

// Use the Client to make requests to the Twilio REST API
$msg=$client->messages->create(
    // The number you'd like to send the message to
    '+919003384088',
    [
        // A Twilio phone number you purchased at https://console.twilio.com
        'from' => '+16076899726',
        // The body of the text message you'd like to send
        'body' => "Hey Jenny! Good luck on the bar exam!"
    ]
);
if($msg)
{
    echo'msg sent';
}
else{
    echo'not working';
}
?>